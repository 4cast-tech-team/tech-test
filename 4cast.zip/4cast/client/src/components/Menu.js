import React, { Component } from "react";
import { Menu } from 'semantic-ui-react';
import { FaUser, FaHome, FaClipboard, FaChartLine, FaEnvelopeOpenText } from 'react-icons/fa';


export default class MenuExampleBasic extends Component {
    state = {}
  
    handleItemClick = (e, { name }) => this.setState({ activeItem: name })
  
    render() {
      const { activeItem } = this.state;
  
      return (
        <Menu>
          <Menu.Item
            name='Users'
            active={activeItem === 'users'}
            onClick={this.handleItemClick}
          >
          <div className="menuIcon">
          {/* <Image src={require('../img/download.jpg')} size='small' /> */}
            Tennants&nbsp;&nbsp;&nbsp;<FaUser /></div>
          </Menu.Item>
  
          <Menu.Item
            name='Properties'
            active={activeItem === 'properties'}
            onClick={this.handleItemClick}
          >
            <div className="menuIcon">
            Properties&nbsp;&nbsp;&nbsp;<FaHome /></div>
          </Menu.Item>
  
          <Menu.Item
            name='Guide'
            active={activeItem === 'guide'}
            onClick={this.handleItemClick}
          >
            <div className="menuIcon">
            Guide&nbsp;&nbsp;&nbsp;<FaClipboard /></div>
          </Menu.Item>
          <Menu.Item
            name='Dashboard'
            active={activeItem === 'dashboard'}
            onClick={this.handleItemClick}
          >
            <div className="menuIcon">
            Analytics&nbsp;&nbsp;&nbsp;<FaChartLine /></div>
          </Menu.Item>
          <Menu.Item
            name='Contact Us'
            active={activeItem === 'contactUs'}
            onClick={this.handleItemClick}
          >
            <div className="menuIcon">
            Contact Us&nbsp;&nbsp;&nbsp;<FaEnvelopeOpenText /></div>
          </Menu.Item>
        </Menu>
      )
    }
  }
  