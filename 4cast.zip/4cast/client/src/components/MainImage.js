import React from 'react';
import { Image } from 'semantic-ui-react';


const MainImage = () => (
    <Image src={require('../img/images.jpg')} size="small" />
      )
  
  export default MainImage