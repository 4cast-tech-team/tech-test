import React, { useState, useEffect } from "react";
import { Container, Divider, Header, Popup, Card, Rating } from "semantic-ui-react";
import { FaCalendar, FaEquals } from 'react-icons/fa';

// COMPONENTS
import Menu from './components/Menu';
import SearchBar from './components/SearchBar';
import MainImage from './components/MainImage';

// SERVICES
import productService from './services/productService';

function App() {
  const [products, setproducts] = useState(null);

  useEffect(() => {
    if(!products) {
      getProducts();
    }
  })

  const getProducts = async () => {
    let res = await productService.getAll();
    console.log(res);
    setproducts(res);
  }

  const renderProduct = product => {
    return (
      <Popup 
      trigger={
        <Card>
      <li key={product._id} className="list__item product">
        <img className="product__image" src={product.image} alt={product.name} />
      <Card.Content>
      <Card.Header><h3 className="product__name">{product.name}</h3></Card.Header>
      <Card.Description><p className="product__description">{product.description}</p></Card.Description>
      </Card.Content>
      </li>
      </Card>
      }
      position='bottom left'
      >
      <Popup.Header>User Rating</Popup.Header>
        <Popup.Content>
          <Rating icon='star' defaultRating={3} maxRating={4} />
        </Popup.Content>
      </Popup>
    );
  };

  return (
    <div className="App">
      <Container text>
    <Header>
      <div className="headerWrapper">
        <div className="menuDots"><FaCalendar /></div>
          <h3 className="titleHeaderBold">4Cast&nbsp;<p className="titleHeader">Test</p></h3>
        <div className="menuEquals"><FaEquals/></div>
      </div>
    </Header>
      <div className="mainImage">
      <MainImage size='small' />
      <Header>
        <h1 className="titleHeaderSlogan">Secondary Strapline<br></br>Title</h1>
      </Header>
      </div>
      <div className="searchBar">
      <SearchBar icon={{ name: 'search', circular: true, link: true }} placeholder='Search...' />
      </div>
        <h5 className="scrollTitle">Small Heading</h5>
      <div className="menuWrapper">
        <Menu></Menu>
      </div>
      <Divider hidden/>
      <ul className="list">
        {(products && products.length > 0) ? (
          products.map(product => renderProduct(product))
        ) : (
          <p>No products found</p>
        )}
      </ul>
      </Container>
    </div>
  );
}

export default App;
