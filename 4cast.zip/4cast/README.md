 /$$   /$$  /$$$$$$                        /$$    
| $$  | $$ /$$__  $$                      | $$    
| $$  | $$| $$  \__/  /$$$$$$   /$$$$$$$ /$$$$$$  
| $$$$$$$$| $$       |____  $$ /$$_____/|_  $$_/  
|_____  $$| $$        /$$$$$$$|  $$$$$$   | $$    
      | $$| $$    $$ /$$__  $$ \____  $$  | $$ /$$
      | $$|  $$$$$$/|  $$$$$$$ /$$$$$$$/  |  $$$$/
      |__/ \______/  \_______/|_______/    \___/  

              |------TECH TEST-----|



             # node-react-tech-test 

Welcome to your tech test for 4cast.

This is a simple fullstack starter application using Node.js, Express.js, React.js and MongoDB

The front end code is in React.js.

React uses Javacript along with jsx which is very similar to html. You can also add css in the App.css folder too.

To setup the project Please run the following commands in the correct folders of the this project using your computers Terminal / Command Prompt. 

To run this project you need to add the backend and frontend dependencies.

Pleass make sure you have already downloaded Node.js and installed the Node Project Manager (npm) before you start running the following commands. 

Guides:

Windows:
https://blog.teamtreehouse.com/install-node-js-npm-windows

MacOS:
https://treehouse.github.io/installation-guides/mac/node-mac.html


Then:

In the root folder (4cast/) of the project run the following command

```
$ npm install
```

Then, navigate to the client directory (4cast/client/) and run the following command:

```
$ yarn
```
or
```
$ npm install
```


## Running the application

*To run this application, you must have MongoDB up and running too*

### To install mongodb please visit this link:

https://docs.mongodb.com/manual/installation/

then choose your Operating System:
ie. MacOs || Linux || Windows


for Mac Users you may find these commands useful after installing mongodb:

#### first install homebrew
npm install homebrew

then run: 

brew tap mongodb/brew
brew install mongodb-community@4.2
brew services start mongodb-community

##### Check if mongodb is running
ps aux | grep -v grep | grep mongod

for windows please use this link to install mongodb:

https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/


###### Running the Application

To run the application, use the following command:

```
$ npm run dev
```


# # Using The Built-In API

The Api is built in Node.js

To view the API products just run: 

npm run server then head to:

http://localhost:5000/api/product

(npm run dev will also start the API)

make either a get or delete or post request for the following

'GET' http://localhost:5000/api/product
'POST' http://localhost:5000/api/product 

{
  "name": "New Product Name Here",
  "description": "Product Description Here",
  "image": "https://www.anykind.of/image/url/here"
}


To delete a product just add the id from the response to the url.

For Example after posting a product you will get this response:

{
    "error": false,
    "product": {
        "_id": "5dcd61edb6cfbc2de11f9c6e",
        "name": "New Product Name",
        "description": "The Description",
        "image": "https://www.image.com/uploads/image.jpg",
        "__v": 0
    }
}

Then simply add te id to the api/product to the url and the item will be deleted when you travel to that endpoint.

So,

http://localhost:5000/api/product/5dcd61edb6cfbc2de11f9c6e

will delete the aforementioned product above.

Once you have the project up and running, we would like you to complete the following tasks:


TASKS:

 * Send a screenshot of the application up and running to your github repository and send us the link to that repository.

 ADDITIONAL TASKS:
 
 * Restyle the UI to be any kinds of colors / design that you like.

 * Edit the files client/src/App.js and client/src/index.css to provide a desktop responsive theme (mobile is already setup).

 * Send the code to your git repository (add node_modules to your .gitignore file or simply delete the modules when you are done).

BONUS TASKS:

 * Make the drop down menu functional on click.

 * Be able to add and delete products using the API. - you can add screen shots to show you have done this.
